<?php
		include 'upload.php';
		include 'database/php_database_conection.php';
		
 
?> 
<html>
<head><title>database php</title>
</head>
<body>


<form action="" method="post" enctype="multipart/form-data">
name of pano: <input id="pano_name" name="pano_name" value="pano_name" type="text"><br>

    backround image:
    <input type="file" name="fileToUpload" id="fileToUpload"><br>
    <input type="submit" value="Upload" name="Upload">
</form>
<br><br><br><br><br><br>

<form action="loadPano.php" method="post" enctype="multipart/form-data">

<?php 
DropDown($con);
?>
    <input type="submit" value="Upload" name="Load">
</form>
<?php showPanos($con);?>

</body>
</html>


