<?php

echo '<script type="text/javascript">',
     'alert("something");',
     '</script>'
;

?>