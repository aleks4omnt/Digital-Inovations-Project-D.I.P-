<?php

		include 'load.php';
		showPanos($id,$con);
			// echo $arr[2];
		$backround=$arr;
		$pano=$id;
		?>
<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" href="scrypts/style.css">
<script src="scrypts/jquery-3.2.1.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<script src="database/jquery_database call.js"></script>
<script src="scrypts/scrypts.js" type="text/javascript"></script>
<script src="scrypts/nicEdit2.js" type="text/javascript"></script>
  <meta charset="UTF-8">
<title>php -feature testing html</title>

<form name="form" action="" method="get">
<div id="pano_ID" name ="pano_ID" type="text" value="<?php echo $pano;?>"></div>
</form>

</head>

<body onload="EditSwitchCheck()">
<script>
<!-- window.onload = EditSwitchCheck(); -->

</script>
<div id="bigImage" class="bigImage" >

<label class="switch" onMouseOver="this.style.cursor='pointer'" >
<input type="checkbox" id="togBtn" onclick="toggleEdit()" checked>
<div class="slider round">
<span class="on">View</span>
<span class="off">Edit</span>
</div>
</label>

<img id="dragNdrop" class="EditSwitch" src="images/exclamation.png" 
draggable="true" ondragstart="drag(event)"
 style="width:50px;height:50px;  
position:absolute; top: 100px; left: 50px;";
onMouseOver="this.style.cursor='pointer'"
/ >

<img id="TrashCan" class="EditSwitch" src="images/recycle.png" 
 style="width:50px;height:50px;  
position:absolute; top: 200px; left: 50px;";
onMouseOver="this.style.cursor='pointer'" 
ondragover="allowDrop(event)" 
draggable="false"
ondrop="deleteDrop(event)"
/ >


<!--<img id="QuestionMark" class="EditSwitch" src="images/question.png" 
 style="width:50px;height:50px;  
position:absolute; top: 200px; left: 150px;";
onMouseOver="this.style.cursor='pointer'" 
onclick="pano_ID()"
draggable="false"
/ >-->


<img class="backroundImg" src="<?php echo $backround;?>" 
onmousedown="return false"
ondragover="allowDrop(event)" 
draggable="false"
ondrop="drop(event)"
/ >

<?php

ShowHotspotsInPano($pano,$con);
				


?>
</body>


<script "type="text/javascript">


</script>

<?php

		// $id =$_POST['dropDown'];
		// echo $id,"<br><br><br>";
		// showPanos($id,$con);
		// function showPanos($id,$con){
// $query = "SELECT * FROM `pano model`.panos WHERE `Pano_ID`='$id'";
// if ($stmt = $con->prepare($query)) {
    // $stmt->execute();
    // $stmt->bind_result($field1, $field2, $field3, $field4);
    // while ($stmt->fetch()) {
        // printf("%s, %s, %s, %s\n", $field1, $field2, $field3, $field4);
		// echo "<br>";
    // }
    // $stmt->close();
// }
	// echo "<img src=$field4>";
	

// }
?>
