<?php
		include 'database/php_database_conection.php';
		include 'database/database_queries.php';

 
?> 
<?php
if (isset($_POST['Upload']))
{
$id=NewPano($_POST['pano_name'],$con) ;
	@mkdir("panos/pano$id",0777,true);



$target_dir = "panos/pano$id/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$imgName=$_FILES["fileToUpload"]["name"];
$souce="$target_dir/$imgName";
// echo "<img src='$souce'>";
addImage($imgName,$souce,$con,$id);
}



function NewPano($pano_name,$con) {
$query ="INSERT INTO `pano model`.`panos` (`pano_name`) VALUES ('$pano_name')" ;
if ($stmt = $con->prepare($query)) {
	$stmt->execute();
    $stmt->close();
}
		$last_id = $con->insert_id;
		return $last_id;
}

function addImage($imgName,$imgSource,$con,$id) {
$query ="UPDATE `pano model`.`panos` SET `IMG_name`='$imgName', `IMG_source`='$imgSource' WHERE `Pano_ID`='$id'" ;
if ($stmt = $con->prepare($query)) {
	$stmt->execute();
    $stmt->close();
}
		$last_id = $con->insert_id;
		return $last_id;
}

function DropDown($con){
$query = "SELECT Pano_ID , pano_name FROM `pano model`.`panos`";
if ($stmt = $con->prepare($query)) {
    $stmt->execute();
    $stmt->bind_result($field1, $field2);
	echo '<select name="dropDown">';
    while ($stmt->fetch()) {
        // printf("%s, %s\n", $field1, $field2);
		// echo "<br>";
		echo "<option value=$field1>$field1,$field2</option>";
    }
		echo '</select>';

    $stmt->close();
}
	
}



function showPanos($con){
$query = "SELECT * FROM `pano model`.panos";
if ($stmt = $con->prepare($query)) {
    $stmt->execute();
    $stmt->bind_result($field1, $field2, $field3, $field4);
    while ($stmt->fetch()) {
        printf("%s, %s, %s, %s\n", $field1, $field2, $field3, $field4);
		echo "<br>";
    }
    $stmt->close();
}
}
$con->close();
?>